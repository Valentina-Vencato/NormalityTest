## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----packages-----------------------------------------------------------------
library(NormalityTest)

## -----------------------------------------------------------------------------
head(iris)

## -----------------------------------------------------------------------------
normality.df(iris)

## ---- fig.width=7, fig.height=5-----------------------------------------------
normality.df(iris, output = "figure")

## ---- fig.width=8-------------------------------------------------------------
Res<-normality.df(iris, output = "message")
Res$pvalues["PetWid"]

