#' Iris Data
#'
#' @description
#' This famous (Fisher's or Anderson's) iris data set gives the measurements in centimeters of the variables sepal length and width and petal length and width, respectively, for 50 flowers from each of 3 species of iris. The species are Iris setosa, versicolor, and virginica.
#'
#' @usage
#' iris
#' iris3
#'
#' @format
#' A `data.frame` with `r nrow(iris)` rows and `r ncol(iris)` columns named: `Sepal.Length, Sepal.Width, Petal.Length, Petal.Width,` and `Species`.
#'
#' @author My Name <balabla@mail.org>
#'
#' @references
#' Becker, R. A., Chambers, J. M. and Wilks, A. R. (1988) The New S Language. Wadsworth & Brooks/Cole. (has iris3 as iris.)


"iris"
